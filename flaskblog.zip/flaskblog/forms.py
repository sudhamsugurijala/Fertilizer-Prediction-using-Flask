from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, BooleanField,DecimalField
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError
from flaskblog.models import User


class RegistrationForm(FlaskForm):
    username = StringField('Username',
                           validators=[DataRequired(), Length(min=2, max=20)])
    email = StringField('Email',
                        validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    confirm_password = PasswordField('Confirm Password',
                                     validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Sign Up')

    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('That username is taken. Please choose a different one.')

    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('That email is taken. Please choose a different one.')


class LoginForm(FlaskForm):
    email = StringField('Email',
                        validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')

class InputForm(FlaskForm):
    calcium = DecimalField('calcium ',validators=[DataRequired()])
    magnesium= DecimalField( 'magnesium',validators=[DataRequired()])
    potassium = DecimalField('potassium ',validators=[DataRequired()])
    sulphur = DecimalField('sulphur ',validators=[DataRequired()])
    nitrogen = DecimalField('nitrogen ',validators=[DataRequired()])
    lime= DecimalField('lime ',validators=[DataRequired()])
    carbon=DecimalField('carbon ',validators=[DataRequired()])
    phosphorous=DecimalField('phosphorous ',validators=[DataRequired()])
    moisture=DecimalField('moisture ',validators=[DataRequired()])
    submit = SubmitField('Predict')